# 💌 가상 스마트폰 엿보기

순수 HTML/CSS/JS — 빌드 없이 동작합니다.

## 파일 구조
```
index.html   화면 뼈대
style.css    디자인
script.js    동작 (앱 추가는 APPS 객체에 항목 추가)
data.js      모든 문구·날짜·비밀번호·타이밍
images/dday.jpg   디데이 앱 이미지 (세로로 긴 커플 일러스트)
images/puppy.jpg  카톡 강아지 사진
```

## GitHub Pages 배포
1. GitHub에 새 저장소를 만들고 이 폴더의 파일을 **그대로 루트에** 올립니다.
2. Settings → Pages → Source: `Deploy from a branch` → Branch: `main` / `/ (root)` → Save.
3. 1~2분 뒤 `https://아이디.github.io/저장소이름/` 으로 접속.

## 이미지 교체
`images/` 폴더에 같은 파일명(`dday.jpg`, `puppy.jpg`)으로 덮어쓰기 하면 됩니다.

## data.js 수정
- `password`: 잠금 비밀번호 (기본 0826)
- `dateText`, `clock`: 잠금화면 날짜/시간
- `kakaoNotifyDelay`: 홈 진입 후 카톡 알림까지 시간(ms)
- `kakao.messages`: 채팅 내용 / `kakao.draft`: 미리 입력된 문구 / `kakao.replies`: 답장
- `memos`, `instagram`, `youtube`, `settings`, `calendarEvents`: 더미 앱 내용
